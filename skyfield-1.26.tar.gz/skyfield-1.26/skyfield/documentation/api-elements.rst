
==================================
 API Reference — Orbital Elements
==================================

.. currentmodule:: skyfield.elementslib

.. autofunction:: osculating_elements_of

.. autoclass:: OsculatingElements
   :members:
